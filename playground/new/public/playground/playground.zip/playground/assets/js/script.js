
// === Theme Toggle ===
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('themeToggle');
  if (toggle) {
    toggle.addEventListener('click', () => {
      document.body.classList.toggle('light-mode');
    });
  }

  // === Notes LocalStorage Support ===
  const notesBox = document.getElementById('qaNotes');
  if (notesBox) {
    const key = window.location.pathname + '_notes';
    const saved = localStorage.getItem(key);
    if (saved) {
      notesBox.value = saved;
    }

    window.saveNotes = () => {
      localStorage.setItem(key, notesBox.value);
    };

    window.clearNotes = () => {
      notesBox.value = '';
      localStorage.removeItem(key);
    };
  }
});
